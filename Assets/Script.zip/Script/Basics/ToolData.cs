using UnityEngine;

public class ToolData : MonoBehaviour
{
    public Vector3 originalPosition;
    public Transform originalParent;
}